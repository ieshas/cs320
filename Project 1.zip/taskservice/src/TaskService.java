import java.util.ArrayList;


public class TaskService {
	private static ArrayList<Task> tasks = new ArrayList<>();

	public TaskService() {
		tasks = new ArrayList<>();
	}

	public static boolean addTask(Task task) {
		boolean existing = false;

		for (Task taskList : tasks) {
			if (taskList.getID().equals(task.getID())) {
				existing = true;
				break;
			}
		}
		if (!existing) {
			tasks.add(task);
			return true;

		}
		return false;
	}

	public boolean deleteTask(String ID) {
		for (Task taskList : tasks) {
			if (taskList.getID().equals(ID)) {
				tasks.remove(taskList);
				return true;
			}
		}
		return false;
	}

	public boolean updateTask(Task task) {
		for (Task taskList : tasks) {
			if (taskList.getID().equals(task.getID())) {
				taskList.setName(task.getName());
				taskList.setDescription(task.getDescription());
				return true;
			}
		}
		return false;
	}
}