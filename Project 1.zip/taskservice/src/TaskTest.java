import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void taskTest() {
		Task task = new Task("123", "Joe", "description");
	}

	@Test
	void testID() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("01234567890", "Joe", "description");
		});
	}

	@Test
	void nullID() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Joe", "description");
		});
	}

	@Test
	void testName() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "JoeJoeJoeJoeJoeJoeJoeJoeJoe", "description");
		});
	}

	@Test
	void nullName() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", null, "description");
		});
	}

	@Test
	void testDescription() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "Joe", "abcdefghijklmnopqrstuvwxyz////abcdefghijklmnopqrstuvwxyz");
		});
	}

	@Test
	void nullDescription() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123", "Joe", null);
		});
	}
}