import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
    TaskService task = new TaskService();

    @Test
    void addTask() {
        Task task1 = new Task("283230", "Homework", "description");
        Task task2 = new Task("14", "Dishes", "description");

        assertTrue(task.addTask(task1));
        assertTrue(task.addTask(task2));

        assertFalse(task.addTask(task1));
    }

    @Test
    void deleteTask() {
        Task task1 = new Task("283230", "Homework", "description");
        Task task2 = new Task("14", "Dishes", "description");

        task.addTask(task1);
        task.addTask(task2);

        assertTrue(task.deleteTask("283230"));
        assertFalse(task.deleteTask("50"));

    }

    @Test
    void update() {

        Task task1 = new Task("283230", "Homework", "description");
        Task task2 = new Task("14", "Dishes", "description");
        task.addTask(task1);
        task.addTask(task2);

    }

}