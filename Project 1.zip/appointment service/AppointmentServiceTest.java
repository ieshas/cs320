import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

class AppointmentServiceTest {

    @Test
    void add() {
        Appointment test1 = new Appointment("012", new Date(), "description");
        assertTrue(AppointmentService.addAppointment(test1));
    }

    @Test
    void delete() {
        Appointment test1 = new Appointment("012", new Date(), "description");
        AppointmentService.addAppointment(test1);


        assertTrue(AppointmentService.deleteAppointment("012"));
    }
}