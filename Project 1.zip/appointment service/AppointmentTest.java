import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    @Test
    void testAppointment() {
        Date now = new Date();
        Appointment appointment = new Appointment("1234", now, "a description");
        assertEquals("1234", appointment.getID());
        assertEquals(appointment.getDate(), now);
        assertEquals("a description", appointment.getDescription());
    }

    @Test
    void longID() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("01234567890123456789", new Date(), "a description");
        });
    }

    @Test
    void idNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, new Date(), "a description");
        });
    }

    @Test
    void pastDate() {
        Date now = new Date();
         Date past = new  Date(now.getTime() - 1);
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234", past, "a description");
        });
    }

    @Test
    void dateNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234", null, "a description");
        });
    }

    @Test
    void longDescription() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234", new Date(), "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Elit scelerisque mauris pellentesque pulvinar pellentesque habitant.");
        });
    }

    @Test
    void descriptionNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment ("1234", new Date(), null);
        });
    }
}