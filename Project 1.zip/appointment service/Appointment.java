import java.util.Date;
public class Appointment {
    private final String ID;
    private final Date date;
    private final String description;

    public Appointment(String ID, Date date, String description) {
        if (ID == null || ID.length() > 10) {
            throw new IllegalArgumentException("ID invalid");
        }
        if (date == null || date.before(new Date())) {
            throw new IllegalArgumentException("invalid date");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("description too long");
        }

        this.ID = ID;
        this.date = date;
        this.description = description;
    }

    public String getID() {
        return ID;
    }

    public Date getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

}
