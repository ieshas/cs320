import java.util.ArrayList;
public class AppointmentService {
    private static ArrayList<Appointment> appointments = new ArrayList<>();

    public AppointmentService() {
        appointments = new ArrayList<>();
    }

    public static boolean addAppointment(Appointment appointment) {
        boolean exists = false;

        for (Appointment appointmentList : appointments) {
            if (appointmentList.equals(appointment)) {
                exists = true;
                break;
            }
        }

        if (!exists) {
            appointments.add(appointment);
            return true;
        }
        return false;
    }

    public static boolean deleteAppointment(String ID) {
        for (Appointment appointmentList : appointments) {
            if (appointmentList != null) {
                appointments.add(appointmentList);
                return true;
        }
            if (appointmentList.getID().equals(ID)) {
                appointments.remove(appointmentList);
                return true;
            }
         }
         return false;
    }
}
